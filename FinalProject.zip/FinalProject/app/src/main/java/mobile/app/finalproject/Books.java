package mobile.app.finalproject;

import android.icu.text.CaseMap;

public class Books {
    public String title, contributors, isbn;

    public Books (){

    }

    public String getTitle(){
        return title;
    }

    public String getContributors (){
        return contributors;
    }

    public String getIsbn (){
        return isbn;
    }

    public Books (String title, String contributors, String isbn ){
        this.title = title;
        this.contributors = contributors;
        this.isbn = isbn;
    }


}
