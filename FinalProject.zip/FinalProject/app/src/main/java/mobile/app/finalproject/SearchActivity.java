package mobile.app.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.ImageButton;

public class SearchActivity extends AppCompatActivity {

    private EditText firebaseSearch;
    private ImageButton searchButton;
    private RecyclerView resultList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        firebaseSearch = findViewById(R.id.firebaseSearch);
        resultList = findViewById(R.id.resultList);
        searchButton = findViewById(R.id.searchButton_);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseBookSearch();
            }
        });

    }


    private void firebaseBookSearch () {
        FirebaseRecyclerAdapter <Books, BooksViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter <Books, BooksViewHolder> (){
            @Override
            protected void populateViewHolder(BooksViewHolder viewHolder, Books model, int position){

            }
        };

    }


    public class BooksViewHolder extends RecyclerView.ViewHolder{

        View mView;
        public BooksViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
        }

    }
}