package mobile.app.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class SellActivity extends AppCompatActivity {

    private EditText sellBookTitle, sellBookContributor, sellBookISBN, sellBookPrice;
    private Button submit;
    private ImageButton gotoSearch;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference root = database.getReference().child("TextBooks");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);

        sellBookContributor = findViewById(R.id.sellBookContributor);
        sellBookISBN = findViewById(R.id.sellBookISBN);
        sellBookTitle = findViewById(R.id.sellBookTitle);
        sellBookPrice = findViewById(R.id.sellBookPrice);
        submit = findViewById(R.id.submit);
        gotoSearch = findViewById(R.id.gotoSearch);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = sellBookTitle.getText().toString();
                String contributor = sellBookContributor.getText().toString();
                String isbn = sellBookISBN.getText().toString();
                String price = sellBookPrice.getText().toString();

                HashMap<String, String> bookMap = new HashMap<>();

                bookMap.put("title", title);
                bookMap.put("contributor", contributor);
                bookMap.put("isbn", isbn);
                bookMap.put("price", price);

                root.push().setValue(bookMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(SellActivity.this, "Text Book Listed", Toast.LENGTH_LONG).show();
                    }
                });

            }


        });
        gotoSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SellActivity.this, SellActivity.class));
            }
        });
    }


}